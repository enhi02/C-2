﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ASMC2
{
    class Program
    {
        static string connection = @"Server=TUNGTEK-LAM0019\MSSQLSERVER08;Database=Asm_C2;Trusted_Connection=True;";            
        static void Main(string[] args)            
        {            
Console.OutputEncoding = Encoding.UTF8;
            bool flagTieptuc = false;
            string n;
            int value;
            Yeucau yc = new Yeucau(connection);
            do
            {
                Console.Clear();
                flagTieptuc = false;
                Console.WriteLine("\n\t--- MENU ---");
                Console.WriteLine("\t1. Nhập lớp học.");
                Console.WriteLine("\t2. In danh sách lớp");
               
                Console.WriteLine("\t0. Thoát.");
                Console.WriteLine("");

                Console.Write("Nhập lựa chọn: ");
                n = Console.ReadLine();
                while (int.TryParse(n, out value) == false)
                {
                    Console.Write("\n yêu cầu  nhập số : ");
                    n = Console.ReadLine();
                }

                switch (value)
                {
                    case 1: yc.Yeucau01(); break;
                    case 2: yc.Yeucau02(); break;
                    
                    case 0:
                    default:
                        Console.WriteLine("\tBạn đã nhập sai chức năng. Vui lòng nhập lại!");
                        break;
                }

                if (value != 0)
                {
                    flagTieptuc = true;
                }
            } while (flagTieptuc);
            Console.ReadLine();
        }

    }
}

